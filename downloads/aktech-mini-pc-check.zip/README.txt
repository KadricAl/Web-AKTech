============================================================
       AK TECH · MINI HARDWARE & PC HEALTH CHECK
             Verzija 1.0 (2026 Portable Edition)
============================================================

Hvala vam na preuzimanju oficijelne AK Tech aplikacije!

UPUTSTVO ZA KORIŠTENJE:
1. Pokrenite 'AKTech-MiniHardwareCheck.exe' (nije potrebna instalacija).
2. Aplikacija će automatski očitati komponente vašeg računara
   i izračunati 'AK Tech PC Health Score'.
3. Klikom na 'Kopiraj Izvještaj' možete sačuvati tehnički sažetak
   i poslati ga AK Tech servisu za besplatne konsultacije.

DOKUMENTACIJA:
Otvorite 'user-guide.html' u bilo kojem internet pregledniku
za detaljan pregled bodovanja, savjeta i mogućnosti.

KONTAKT & PODRŠKA:
• Web Portal:    https://aktech.work
• WhatsApp/Tel:  +387 61 293 073
• OLX Prodavnica: https://olx.ba/profil/AKTech
• Email:         support@aktech.work
• Servis:        Vogošća / Sarajevo

(c) 2026 AK TECH. Sva prava zadržana.
