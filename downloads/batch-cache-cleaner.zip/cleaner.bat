@echo off
echo AK Tech System Cache Cleaner
pause