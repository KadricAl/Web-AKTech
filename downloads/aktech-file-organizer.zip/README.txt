============================================================
         AK TECH · SMART FILE ORGANIZER (PORTABLE)
                Verzija 1.0 (2026 Edition)
============================================================

Hvala vam na preuzimanju oficijelnog AK Tech alata!

BRZI START:
1. Raspakujte sve datoteke iz ZIP arhive u folder po zelji.
2. Pokrenite 'AKTech-FileOrganizer.exe' (nije potrebna instalacija).
3. Izaberite folder (Downloads, Desktop, Documents ili vlastiti).
4. Pregledajte Dry-Run listu i kliknite 'Organizuj Fajlove'.
5. Ako zelite ponistiti promjene, kliknite 'Undo'.

SIGURNOSNE MJERE:
- .lnk i .url precice, skriveni fajlovi i aktivni downloadi se ne diraju.
- Fajlovi istog imena se nikad ne prepisuju (dobijaju broj (1), (2)...).

UPUTSTVO:
Otvorite 'user-guide.html' u pregledniku za detaljan opis kategorija.

KONTAKT & PODRSKA:
• Web Portal:    https://aktech.work
• WhatsApp/Tel:  +387 61 293 073
• OLX Prodavnica: https://olx.ba/profil/AKTech
• Email:         support@aktech.work

(c) 2026 AK TECH. Sva prava zadrzana.
