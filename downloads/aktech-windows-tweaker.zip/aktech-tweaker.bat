@echo off
echo AK Tech Windows Tweaker Placeholder
pause